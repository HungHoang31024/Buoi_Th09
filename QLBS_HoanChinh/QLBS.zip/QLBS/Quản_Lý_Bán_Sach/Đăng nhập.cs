﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quản_Lý_Bán_Sach
{
    public partial class Đăng_nhập : Form
    {
        public Đăng_nhập()
        {
            InitializeComponent();
        }

        private void btnDN_Click(object sender, EventArgs e)
        {
            if ((this.txtTTK.Text == "") || (this.txtMK.Text == ""))
            {

                MessageBox.Show("Vui lòng nhập tên người dùng hoặc mật khẩu");
            }
            else
            {
                if ((this.txtTTK.Text == "qlNhuQuynh") && (this.txtMK.Text == "9999."))
                {
                    MessageBox.Show("Đăng nhập thành công", "Thông báo");
                    Chức_năng CN = new Chức_năng();
                    CN.ShowDialog();
                    //this.Close();
                }
                else if ((this.txtTTK.Text == "NVQuynhCongChua") && (this.txtMK.Text == "9999."))
                {
                    MessageBox.Show("Đăng nhập thành công", "Thông báo");
                    Chức_năng_nhân_viên CNNV = new Chức_năng_nhân_viên();
                    CNNV.ShowDialog();
                    //this.Close();
                }
                else if ((this.txtTTK.Text == "QLMinhAnh") && (this.txtMK.Text == "12345."))
                {
                    MessageBox.Show("Đăng nhập thành công", "Thông báo");
                    Chức_năng_nhân_viên CNNV = new Chức_năng_nhân_viên();
                    CNNV.ShowDialog();
                    //this.Close();
                }
                else if ((this.txtTTK.Text == "NVMinhAnh") && (this.txtMK.Text == "abc12345."))
                {
                    MessageBox.Show("Đăng nhập thành công", "Thông báo");
                    Chức_năng_nhân_viên CNNV = new Chức_năng_nhân_viên();
                    CNNV.ShowDialog();
                    //this.Close();
                }
                else if ((this.txtTTK.Text == "NVQuynhCongChua") && (this.txtMK.Text == "9999."))
                {
                    MessageBox.Show("Đăng nhập thành công", "Thông báo");
                    Chức_năng_nhân_viên CNNV = new Chức_năng_nhân_viên();
                    CNNV.ShowDialog();
                    //this.Close();
                }
                else if ((this.txtTTK.Text == "qlHoangHung") && (this.txtMK.Text == "98765."))
                {
                    MessageBox.Show("Đăng nhập thành công", "Thông báo");
                    Chức_năng_nhân_viên CNNV = new Chức_năng_nhân_viên();
                    CNNV.ShowDialog();
                    //this.Close();
                }
                else if ((this.txtTTK.Text == "nvHoangHung") && (this.txtMK.Text == "abc98765."))
                {
                    MessageBox.Show("Đăng nhập thành công", "Thông báo");
                    Chức_năng_nhân_viên CNNV = new Chức_năng_nhân_viên();
                    CNNV.ShowDialog();
                    //this.Close();
                }
                else
                {
                    if (this.radGN.Checked == true)
                    {
                        String thongbao = "\n\rBạn có ghi nhớ.";
                    }
                    MessageBox.Show("Tên và mật khẩu không đúng, hãy nhập lại", "Thông báo");
                    this.txtTTK.Clear();
                    this.txtMK.Clear(); this.txtTTK.Focus();
                }
            }
        this.Close();
        }

        private void txtMK_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if ((this.txtTTK.Text == "") || (this.txtMK.Text == ""))
                {

                    MessageBox.Show("Vui lòng nhập tên người dùng hoặc mật khẩu");
                }
                else
                {
                    if ((this.txtTTK.Text == "qlNhuQuynh") && (this.txtMK.Text == "9999."))
                    {
                        MessageBox.Show("Đăng nhập thành công", "Thông báo");
                        Chức_năng CN = new Chức_năng();
                        CN.ShowDialog();
                        this.Close();
                    }
                    else if ((this.txtTTK.Text == "NVQuynhCongChua") && (this.txtMK.Text == "9999."))
                    {
                        MessageBox.Show("Đăng nhập thành công", "Thông báo");
                        Chức_năng_nhân_viên CNNV = new Chức_năng_nhân_viên();
                        CNNV.ShowDialog();
                        this.Close();
                    }
                    else if ((this.txtTTK.Text == "QLMinhAnh") && (this.txtMK.Text == "12345."))
                    {
                        MessageBox.Show("Đăng nhập thành công", "Thông báo");
                        Chức_năng_nhân_viên CNNV = new Chức_năng_nhân_viên();
                        CNNV.ShowDialog();
                        this.Close();
                    }
                    else if ((this.txtTTK.Text == "NVMinhAnh") && (this.txtMK.Text == "abc12345."))
                    {
                        MessageBox.Show("Đăng nhập thành công", "Thông báo");
                        Chức_năng_nhân_viên CNNV = new Chức_năng_nhân_viên();
                        CNNV.ShowDialog();
                        this.Close();
                    }
                    else if ((this.txtTTK.Text == "NVQuynhCongChua") && (this.txtMK.Text == "9999."))
                    {
                        MessageBox.Show("Đăng nhập thành công", "Thông báo");
                        Chức_năng_nhân_viên CNNV = new Chức_năng_nhân_viên();
                        CNNV.ShowDialog();
                        this.Close();
                    }
                    else if ((this.txtTTK.Text == "qlHoangHung") && (this.txtMK.Text == "98765."))
                    {
                        MessageBox.Show("Đăng nhập thành công", "Thông báo");
                        Chức_năng_nhân_viên CNNV = new Chức_năng_nhân_viên();
                        CNNV.ShowDialog();
                        this.Close();
                    }
                    else if ((this.txtTTK.Text == "nvHoangHung") && (this.txtMK.Text == "abc98765."))
                    {
                        MessageBox.Show("Đăng nhập thành công", "Thông báo");
                        Chức_năng_nhân_viên CNNV = new Chức_năng_nhân_viên();
                        CNNV.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        if (this.radGN.Checked == true)
                        {
                            String thongbao = "\n\rBạn có ghi nhớ.";
                        }
                        MessageBox.Show("Tên và mật khẩu không đúng, hãy nhập lại", "Thông báo");
                        this.txtTTK.Clear();
                        this.txtMK.Clear(); this.txtTTK.Focus();
                    }
                }
                this.Close();
            }
        }
    }
}
