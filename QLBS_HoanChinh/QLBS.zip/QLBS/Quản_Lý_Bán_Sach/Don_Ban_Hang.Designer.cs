﻿namespace Quản_Lý_Bán_Sach
{
    partial class Don_Ban_Hang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Don_Ban_Hang));
            this.grbTTSach = new System.Windows.Forms.GroupBox();
            this.txtMaS = new System.Windows.Forms.TextBox();
            this.lblMaS = new System.Windows.Forms.Label();
            this.dtpNBan = new System.Windows.Forms.DateTimePicker();
            this.txtTenS = new System.Windows.Forms.TextBox();
            this.txtSLMua = new System.Windows.Forms.TextBox();
            this.txtDGia = new System.Windows.Forms.TextBox();
            this.txtTTien = new System.Windows.Forms.TextBox();
            this.txtMaHD = new System.Windows.Forms.TextBox();
            this.lblTenS = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTTien = new System.Windows.Forms.Label();
            this.lblSLMua = new System.Windows.Forms.Label();
            this.lblNgayBan = new System.Windows.Forms.Label();
            this.lblMaHD = new System.Windows.Forms.Label();
            this.dgvHD = new System.Windows.Forms.DataGridView();
            this.lsvDSMHang = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader6 = new System.Windows.Forms.ColumnHeader();
            this.btnThemDSM = new System.Windows.Forms.Button();
            this.btnTongT = new System.Windows.Forms.Button();
            this.lblTongT = new System.Windows.Forms.Label();
            this.btnXoaDSM = new System.Windows.Forms.Button();
            this.grbTTSach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHD)).BeginInit();
            this.SuspendLayout();
            // 
            // grbTTSach
            // 
            this.grbTTSach.BackColor = System.Drawing.Color.Bisque;
            this.grbTTSach.Controls.Add(this.txtMaS);
            this.grbTTSach.Controls.Add(this.lblMaS);
            this.grbTTSach.Controls.Add(this.dtpNBan);
            this.grbTTSach.Controls.Add(this.txtTenS);
            this.grbTTSach.Controls.Add(this.txtSLMua);
            this.grbTTSach.Controls.Add(this.txtDGia);
            this.grbTTSach.Controls.Add(this.txtTTien);
            this.grbTTSach.Controls.Add(this.txtMaHD);
            this.grbTTSach.Controls.Add(this.lblTenS);
            this.grbTTSach.Controls.Add(this.label1);
            this.grbTTSach.Controls.Add(this.lblTTien);
            this.grbTTSach.Controls.Add(this.lblSLMua);
            this.grbTTSach.Controls.Add(this.lblNgayBan);
            this.grbTTSach.Controls.Add(this.lblMaHD);
            this.grbTTSach.Location = new System.Drawing.Point(57, 30);
            this.grbTTSach.Name = "grbTTSach";
            this.grbTTSach.Size = new System.Drawing.Size(1809, 206);
            this.grbTTSach.TabIndex = 6;
            this.grbTTSach.TabStop = false;
            this.grbTTSach.Text = "Thông Tin Sách";
            // 
            // txtMaS
            // 
            this.txtMaS.Location = new System.Drawing.Point(1421, 53);
            this.txtMaS.Name = "txtMaS";
            this.txtMaS.Size = new System.Drawing.Size(231, 35);
            this.txtMaS.TabIndex = 4;
            // 
            // lblMaS
            // 
            this.lblMaS.AutoSize = true;
            this.lblMaS.Location = new System.Drawing.Point(1295, 61);
            this.lblMaS.Name = "lblMaS";
            this.lblMaS.Size = new System.Drawing.Size(99, 27);
            this.lblMaS.TabIndex = 3;
            this.lblMaS.Text = "Mã sách:";
            // 
            // dtpNBan
            // 
            this.dtpNBan.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNBan.Location = new System.Drawing.Point(552, 58);
            this.dtpNBan.Name = "dtpNBan";
            this.dtpNBan.Size = new System.Drawing.Size(205, 35);
            this.dtpNBan.TabIndex = 2;
            // 
            // txtTenS
            // 
            this.txtTenS.Location = new System.Drawing.Point(989, 110);
            this.txtTenS.Name = "txtTenS";
            this.txtTenS.Size = new System.Drawing.Size(246, 35);
            this.txtTenS.TabIndex = 1;
            // 
            // txtSLMua
            // 
            this.txtSLMua.Location = new System.Drawing.Point(989, 61);
            this.txtSLMua.Name = "txtSLMua";
            this.txtSLMua.Size = new System.Drawing.Size(246, 35);
            this.txtSLMua.TabIndex = 1;
            // 
            // txtDGia
            // 
            this.txtDGia.Location = new System.Drawing.Point(163, 118);
            this.txtDGia.Name = "txtDGia";
            this.txtDGia.Size = new System.Drawing.Size(205, 35);
            this.txtDGia.TabIndex = 1;
            // 
            // txtTTien
            // 
            this.txtTTien.Location = new System.Drawing.Point(552, 110);
            this.txtTTien.Name = "txtTTien";
            this.txtTTien.Size = new System.Drawing.Size(205, 35);
            this.txtTTien.TabIndex = 1;
            // 
            // txtMaHD
            // 
            this.txtMaHD.Location = new System.Drawing.Point(163, 58);
            this.txtMaHD.Name = "txtMaHD";
            this.txtMaHD.Size = new System.Drawing.Size(197, 35);
            this.txtMaHD.TabIndex = 1;
            // 
            // lblTenS
            // 
            this.lblTenS.AutoSize = true;
            this.lblTenS.Location = new System.Drawing.Point(820, 113);
            this.lblTenS.Name = "lblTenS";
            this.lblTenS.Size = new System.Drawing.Size(107, 27);
            this.lblTenS.TabIndex = 0;
            this.lblTenS.Text = "Tên Sách:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "Đơn Giá:";
            // 
            // lblTTien
            // 
            this.lblTTien.AutoSize = true;
            this.lblTTien.Location = new System.Drawing.Point(410, 118);
            this.lblTTien.Name = "lblTTien";
            this.lblTTien.Size = new System.Drawing.Size(127, 27);
            this.lblTTien.TabIndex = 0;
            this.lblTTien.Text = "Thành Tiền:";
            // 
            // lblSLMua
            // 
            this.lblSLMua.AutoSize = true;
            this.lblSLMua.Location = new System.Drawing.Point(820, 66);
            this.lblSLMua.Name = "lblSLMua";
            this.lblSLMua.Size = new System.Drawing.Size(162, 27);
            this.lblSLMua.TabIndex = 0;
            this.lblSLMua.Text = "Số Lượng Mua:";
            // 
            // lblNgayBan
            // 
            this.lblNgayBan.AutoSize = true;
            this.lblNgayBan.Location = new System.Drawing.Point(410, 66);
            this.lblNgayBan.Name = "lblNgayBan";
            this.lblNgayBan.Size = new System.Drawing.Size(114, 27);
            this.lblNgayBan.TabIndex = 0;
            this.lblNgayBan.Text = "Ngày Bán:";
            // 
            // lblMaHD
            // 
            this.lblMaHD.AutoSize = true;
            this.lblMaHD.Location = new System.Drawing.Point(13, 66);
            this.lblMaHD.Name = "lblMaHD";
            this.lblMaHD.Size = new System.Drawing.Size(144, 27);
            this.lblMaHD.TabIndex = 0;
            this.lblMaHD.Text = "Mã Hóa Đơn:";
            // 
            // dgvHD
            // 
            this.dgvHD.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvHD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHD.Location = new System.Drawing.Point(57, 268);
            this.dgvHD.Name = "dgvHD";
            this.dgvHD.RowHeadersWidth = 62;
            this.dgvHD.RowTemplate.Height = 33;
            this.dgvHD.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHD.Size = new System.Drawing.Size(731, 431);
            this.dgvHD.TabIndex = 7;
            this.dgvHD.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvHD_CellContentClick);
            // 
            // lsvDSMHang
            // 
            this.lsvDSMHang.BackColor = System.Drawing.SystemColors.Control;
            this.lsvDSMHang.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
            this.lsvDSMHang.FullRowSelect = true;
            this.lsvDSMHang.GridLines = true;
            this.lsvDSMHang.Location = new System.Drawing.Point(1001, 268);
            this.lsvDSMHang.Name = "lsvDSMHang";
            this.lsvDSMHang.Size = new System.Drawing.Size(865, 431);
            this.lsvDSMHang.TabIndex = 8;
            this.lsvDSMHang.UseCompatibleStateImageBehavior = false;
            this.lsvDSMHang.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Mã Hóa Đơn";
            this.columnHeader1.Width = 140;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Ngày Bán";
            this.columnHeader2.Width = 120;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Số Lượng Mua";
            this.columnHeader3.Width = 120;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Thành Tiền";
            this.columnHeader4.Width = 130;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Tên Sách";
            this.columnHeader5.Width = 150;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Đơn Giá";
            this.columnHeader6.Width = 150;
            // 
            // btnThemDSM
            // 
            this.btnThemDSM.BackColor = System.Drawing.SystemColors.Control;
            this.btnThemDSM.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnThemDSM.BackgroundImage")));
            this.btnThemDSM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnThemDSM.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnThemDSM.Location = new System.Drawing.Point(817, 387);
            this.btnThemDSM.Name = "btnThemDSM";
            this.btnThemDSM.Size = new System.Drawing.Size(139, 75);
            this.btnThemDSM.TabIndex = 9;
            this.btnThemDSM.Text = ">>";
            this.btnThemDSM.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThemDSM.UseVisualStyleBackColor = false;
            this.btnThemDSM.Click += new System.EventHandler(this.btnThemDSM_Click);
            // 
            // btnTongT
            // 
            this.btnTongT.BackColor = System.Drawing.SystemColors.Control;
            this.btnTongT.Location = new System.Drawing.Point(1156, 705);
            this.btnTongT.Name = "btnTongT";
            this.btnTongT.Size = new System.Drawing.Size(175, 52);
            this.btnTongT.TabIndex = 9;
            this.btnTongT.Text = "Tổng Tiền";
            this.btnTongT.UseVisualStyleBackColor = false;
            this.btnTongT.Click += new System.EventHandler(this.btnTongT_Click);
            // 
            // lblTongT
            // 
            this.lblTongT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lblTongT.Location = new System.Drawing.Point(1387, 705);
            this.lblTongT.Name = "lblTongT";
            this.lblTongT.Size = new System.Drawing.Size(276, 52);
            this.lblTongT.TabIndex = 0;
            this.lblTongT.Text = "0 vnđ";
            this.lblTongT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnXoaDSM
            // 
            this.btnXoaDSM.BackColor = System.Drawing.SystemColors.Control;
            this.btnXoaDSM.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnXoaDSM.BackgroundImage")));
            this.btnXoaDSM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnXoaDSM.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnXoaDSM.Location = new System.Drawing.Point(819, 516);
            this.btnXoaDSM.Name = "btnXoaDSM";
            this.btnXoaDSM.Size = new System.Drawing.Size(137, 79);
            this.btnXoaDSM.TabIndex = 10;
            this.btnXoaDSM.Text = "<<";
            this.btnXoaDSM.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoaDSM.UseVisualStyleBackColor = false;
            this.btnXoaDSM.Click += new System.EventHandler(this.btnXoaDSM_Click);
            // 
            // Don_Ban_Hang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 27F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1924, 769);
            this.Controls.Add(this.btnXoaDSM);
            this.Controls.Add(this.btnTongT);
            this.Controls.Add(this.btnThemDSM);
            this.Controls.Add(this.lsvDSMHang);
            this.Controls.Add(this.dgvHD);
            this.Controls.Add(this.lblTongT);
            this.Controls.Add(this.grbTTSach);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Don_Ban_Hang";
            this.Text = "Đơn bán hàng";
            this.Load += new System.EventHandler(this.Don_Ban_Hang_Load);
            this.grbTTSach.ResumeLayout(false);
            this.grbTTSach.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHD)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private GroupBox grbTTSach;
        private DateTimePicker dtpNBan;
        private TextBox txtTenS;
        private TextBox txtSLMua;
        private TextBox txtTTien;
        private TextBox txtMaHD;
        private Label lblTenS;
        private Label lblTTien;
        private Label lblSLMua;
        private Label lblNgayBan;
        private Label lblMaHD;
        private DataGridView dgvHD;
        private ListView lsvDSMHang;
        private Button btnThemDSM;
        private Button btnTongT;
        private Label lblTongT;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private ColumnHeader columnHeader5;
        private TextBox txtDGia;
        private Label label1;
        private ColumnHeader columnHeader6;
        private Button btnXoaDSM;
        private TextBox txtMaS;
        private Label lblMaS;
    }
}