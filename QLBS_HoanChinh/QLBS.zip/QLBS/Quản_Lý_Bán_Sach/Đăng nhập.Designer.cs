﻿namespace Quản_Lý_Bán_Sach
{
    partial class Đăng_nhập
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Đăng_nhập));
            this.btnDN = new System.Windows.Forms.Button();
            this.lablTTK = new System.Windows.Forms.Label();
            this.txtMK = new System.Windows.Forms.TextBox();
            this.lblMK = new System.Windows.Forms.Label();
            this.radGN = new System.Windows.Forms.RadioButton();
            this.txtTTK = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnDN
            // 
            this.btnDN.BackColor = System.Drawing.Color.DarkGray;
            this.btnDN.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnDN.Location = new System.Drawing.Point(292, 289);
            this.btnDN.Name = "btnDN";
            this.btnDN.Size = new System.Drawing.Size(177, 80);
            this.btnDN.TabIndex = 0;
            this.btnDN.Text = "Đăng nhập";
            this.btnDN.UseVisualStyleBackColor = false;
            this.btnDN.Click += new System.EventHandler(this.btnDN_Click);
            // 
            // lablTTK
            // 
            this.lablTTK.AutoSize = true;
            this.lablTTK.BackColor = System.Drawing.Color.DarkGray;
            this.lablTTK.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lablTTK.ForeColor = System.Drawing.Color.Black;
            this.lablTTK.Location = new System.Drawing.Point(82, 100);
            this.lablTTK.Name = "lablTTK";
            this.lablTTK.Size = new System.Drawing.Size(167, 33);
            this.lablTTK.TabIndex = 1;
            this.lablTTK.Text = "Tên tài khoản";
            // 
            // txtMK
            // 
            this.txtMK.Location = new System.Drawing.Point(279, 175);
            this.txtMK.Name = "txtMK";
            this.txtMK.Size = new System.Drawing.Size(284, 35);
            this.txtMK.TabIndex = 2;
            this.txtMK.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMK_KeyDown);
            // 
            // lblMK
            // 
            this.lblMK.AutoSize = true;
            this.lblMK.BackColor = System.Drawing.Color.DarkGray;
            this.lblMK.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblMK.Location = new System.Drawing.Point(82, 183);
            this.lblMK.Name = "lblMK";
            this.lblMK.Size = new System.Drawing.Size(121, 33);
            this.lblMK.TabIndex = 1;
            this.lblMK.Text = "Mật khẩu";
            // 
            // radGN
            // 
            this.radGN.AutoSize = true;
            this.radGN.BackColor = System.Drawing.Color.DarkGray;
            this.radGN.Location = new System.Drawing.Point(508, 252);
            this.radGN.Name = "radGN";
            this.radGN.Size = new System.Drawing.Size(115, 31);
            this.radGN.TabIndex = 3;
            this.radGN.TabStop = true;
            this.radGN.Text = "Ghi nhớ";
            this.radGN.UseVisualStyleBackColor = false;
            // 
            // txtTTK
            // 
            this.txtTTK.Location = new System.Drawing.Point(279, 100);
            this.txtTTK.Name = "txtTTK";
            this.txtTTK.Size = new System.Drawing.Size(284, 35);
            this.txtTTK.TabIndex = 2;
            // 
            // Đăng_nhập
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 27F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(695, 525);
            this.Controls.Add(this.radGN);
            this.Controls.Add(this.txtTTK);
            this.Controls.Add(this.txtMK);
            this.Controls.Add(this.lblMK);
            this.Controls.Add(this.lablTTK);
            this.Controls.Add(this.btnDN);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Đăng_nhập";
            this.Text = "Đăng_nhập";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnDN;
        private Label lablTTK;
        private TextBox txtMK;
        private Label lblMK;
        private RadioButton radGN;
        private TextBox txtTTK;
    }
}