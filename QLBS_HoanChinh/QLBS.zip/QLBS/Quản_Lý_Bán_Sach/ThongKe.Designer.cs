﻿namespace Quản_Lý_Bán_Sach
{
    partial class ThongKe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThongKe));
            this.dtgThongKeSach = new System.Windows.Forms.DataGridView();
            this.lblNNL = new System.Windows.Forms.Label();
            this.btnTK = new System.Windows.Forms.Button();
            this.dgvTKSNLau = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblSLC = new System.Windows.Forms.Label();
            this.txtSLC = new System.Windows.Forms.TextBox();
            this.btnTKe = new System.Windows.Forms.Button();
            this.dgvTKSLCIt = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cmbNgayNhapS = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtgThongKeSach)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTKSNLau)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTKSLCIt)).BeginInit();
            this.SuspendLayout();
            // 
            // dtgThongKeSach
            // 
            this.dtgThongKeSach.BackgroundColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.NullValue = null;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgThongKeSach.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgThongKeSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgThongKeSach.Location = new System.Drawing.Point(188, 13);
            this.dtgThongKeSach.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dtgThongKeSach.Name = "dtgThongKeSach";
            this.dtgThongKeSach.RowHeadersWidth = 51;
            this.dtgThongKeSach.RowTemplate.Height = 29;
            this.dtgThongKeSach.Size = new System.Drawing.Size(1325, 286);
            this.dtgThongKeSach.TabIndex = 0;
            // 
            // lblNNL
            // 
            this.lblNNL.AutoSize = true;
            this.lblNNL.BackColor = System.Drawing.Color.Thistle;
            this.lblNNL.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNNL.Location = new System.Drawing.Point(44, 338);
            this.lblNNL.Name = "lblNNL";
            this.lblNNL.Size = new System.Drawing.Size(214, 32);
            this.lblNNL.TabIndex = 1;
            this.lblNNL.Text = "Ngày Nhập Sách";
            // 
            // btnTK
            // 
            this.btnTK.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnTK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTK.Location = new System.Drawing.Point(590, 309);
            this.btnTK.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnTK.Name = "btnTK";
            this.btnTK.Size = new System.Drawing.Size(219, 80);
            this.btnTK.TabIndex = 3;
            this.btnTK.Text = "Thống kê";
            this.btnTK.UseVisualStyleBackColor = false;
            this.btnTK.Click += new System.EventHandler(this.btnTK_Click);
            // 
            // dgvTKSNLau
            // 
            this.dgvTKSNLau.BackgroundColor = System.Drawing.Color.Lavender;
            this.dgvTKSNLau.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTKSNLau.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8});
            this.dgvTKSNLau.Location = new System.Drawing.Point(44, 397);
            this.dgvTKSNLau.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgvTKSNLau.Name = "dgvTKSNLau";
            this.dgvTKSNLau.RowHeadersWidth = 62;
            this.dgvTKSNLau.RowTemplate.Height = 33;
            this.dgvTKSNLau.Size = new System.Drawing.Size(765, 234);
            this.dgvTKSNLau.TabIndex = 4;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Mã sách";
            this.Column1.MinimumWidth = 8;
            this.Column1.Name = "Column1";
            this.Column1.Width = 150;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Tên sách";
            this.Column2.MinimumWidth = 8;
            this.Column2.Name = "Column2";
            this.Column2.Width = 150;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Tác giả";
            this.Column3.MinimumWidth = 8;
            this.Column3.Name = "Column3";
            this.Column3.Width = 150;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Tên nhà sản xuất";
            this.Column4.MinimumWidth = 8;
            this.Column4.Name = "Column4";
            this.Column4.Width = 150;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Mã loại";
            this.Column5.MinimumWidth = 8;
            this.Column5.Name = "Column5";
            this.Column5.Width = 150;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Đơn giá";
            this.Column6.MinimumWidth = 8;
            this.Column6.Name = "Column6";
            this.Column6.Width = 150;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "SL tồn";
            this.Column7.MinimumWidth = 8;
            this.Column7.Name = "Column7";
            this.Column7.Width = 150;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Ngày nhập";
            this.Column8.MinimumWidth = 8;
            this.Column8.Name = "Column8";
            this.Column8.Width = 150;
            // 
            // lblSLC
            // 
            this.lblSLC.AutoSize = true;
            this.lblSLC.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSLC.Location = new System.Drawing.Point(874, 330);
            this.lblSLC.Name = "lblSLC";
            this.lblSLC.Size = new System.Drawing.Size(203, 32);
            this.lblSLC.TabIndex = 1;
            this.lblSLC.Text = "Số lượng tồn cũ";
            // 
            // txtSLC
            // 
            this.txtSLC.Location = new System.Drawing.Point(1096, 330);
            this.txtSLC.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSLC.Name = "txtSLC";
            this.txtSLC.Size = new System.Drawing.Size(250, 35);
            this.txtSLC.TabIndex = 2;
            this.txtSLC.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSLC_KeyDown);
            // 
            // btnTKe
            // 
            this.btnTKe.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnTKe.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTKe.Location = new System.Drawing.Point(1352, 306);
            this.btnTKe.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnTKe.Name = "btnTKe";
            this.btnTKe.Size = new System.Drawing.Size(250, 80);
            this.btnTKe.TabIndex = 3;
            this.btnTKe.Text = "Thống kê số lượng tồn";
            this.btnTKe.UseVisualStyleBackColor = false;
            this.btnTKe.Click += new System.EventHandler(this.btnTKe_Click);
            // 
            // dgvTKSLCIt
            // 
            this.dgvTKSLCIt.BackgroundColor = System.Drawing.Color.Lavender;
            this.dgvTKSLCIt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTKSLCIt.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.Column9});
            this.dgvTKSLCIt.Location = new System.Drawing.Point(865, 397);
            this.dgvTKSLCIt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgvTKSLCIt.Name = "dgvTKSLCIt";
            this.dgvTKSLCIt.RowHeadersWidth = 62;
            this.dgvTKSLCIt.RowTemplate.Height = 33;
            this.dgvTKSLCIt.Size = new System.Drawing.Size(777, 234);
            this.dgvTKSLCIt.TabIndex = 5;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Mã sách";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 150;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Tên sách";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 150;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Tác giả";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 150;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Tên nhà xuất";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 150;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Mã loại";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 150;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Đơn giá";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 150;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Số lượng tồn";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 150;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Ngày nhập";
            this.Column9.MinimumWidth = 8;
            this.Column9.Name = "Column9";
            this.Column9.Width = 150;
            // 
            // cmbNgayNhapS
            // 
            this.cmbNgayNhapS.FormatString = "G";
            this.cmbNgayNhapS.FormattingEnabled = true;
            this.cmbNgayNhapS.Location = new System.Drawing.Point(282, 335);
            this.cmbNgayNhapS.Name = "cmbNgayNhapS";
            this.cmbNgayNhapS.Size = new System.Drawing.Size(287, 35);
            this.cmbNgayNhapS.TabIndex = 6;
            this.cmbNgayNhapS.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbNgayNhapS_KeyDown);
            // 
            // ThongKe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 27F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1654, 659);
            this.Controls.Add(this.cmbNgayNhapS);
            this.Controls.Add(this.dgvTKSLCIt);
            this.Controls.Add(this.dgvTKSNLau);
            this.Controls.Add(this.btnTKe);
            this.Controls.Add(this.btnTK);
            this.Controls.Add(this.txtSLC);
            this.Controls.Add(this.lblSLC);
            this.Controls.Add(this.lblNNL);
            this.Controls.Add(this.dtgThongKeSach);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ThongKe";
            this.Text = "ThongKe";
            this.Load += new System.EventHandler(this.ThongKe_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgThongKeSach)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTKSNLau)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTKSLCIt)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView dtgThongKeSach;
        private Label lblNNL;
        private Button btnTK;
        private DataGridView dgvTKSNLau;
        private Label lblSLC;
        private TextBox txtSLC;
        private Button btnTKe;
        private DataGridView dgvTKSLCIt;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private DataGridViewTextBoxColumn Column7;
        private DataGridViewTextBoxColumn Column8;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private DataGridViewTextBoxColumn Column9;
        private ComboBox cmbNgayNhapS;
    }
}