﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quản_Lý_Bán_Sach
{
    public partial class Hướng_dẫn : Form
    {
        public Hướng_dẫn()
        {
            InitializeComponent();
        }

        private void pnlHDQLS_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnback(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
