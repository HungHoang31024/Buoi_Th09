﻿namespace Bài4._3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtMauSo1 = new System.Windows.Forms.TextBox();
            this.txtTuSo1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtMauso2 = new System.Windows.Forms.TextBox();
            this.txtTuso2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.grpPhepTinh = new System.Windows.Forms.GroupBox();
            this.btnThuong = new System.Windows.Forms.Button();
            this.btnTich = new System.Windows.Forms.Button();
            this.btnHieu = new System.Windows.Forms.Button();
            this.btnSum = new System.Windows.Forms.Button();
            this.grpKq = new System.Windows.Forms.GroupBox();
            this.txtKQMau = new System.Windows.Forms.TextBox();
            this.txtKQTu = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnTiep = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.grpPhepTinh.SuspendLayout();
            this.grpKq.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtMauSo1);
            this.groupBox1.Controls.Add(this.txtTuSo1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(105, 81);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(293, 184);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Phân Số 1";
            // 
            // txtMauSo1
            // 
            this.txtMauSo1.Location = new System.Drawing.Point(149, 107);
            this.txtMauSo1.Name = "txtMauSo1";
            this.txtMauSo1.Size = new System.Drawing.Size(120, 30);
            this.txtMauSo1.TabIndex = 3;
            this.txtMauSo1.TextChanged += new System.EventHandler(this.txtMauSo1_TextChanged);
            // 
            // txtTuSo1
            // 
            this.txtTuSo1.Location = new System.Drawing.Point(149, 50);
            this.txtTuSo1.Name = "txtTuSo1";
            this.txtTuSo1.Size = new System.Drawing.Size(120, 30);
            this.txtTuSo1.TabIndex = 2;
            this.txtTuSo1.TextChanged += new System.EventHandler(this.txtTuSo1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Mẫu số:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tử số:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtMauso2);
            this.groupBox2.Controls.Add(this.txtTuso2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(560, 81);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(293, 184);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Phân Số 2";
            // 
            // txtMauso2
            // 
            this.txtMauso2.Location = new System.Drawing.Point(149, 107);
            this.txtMauso2.Name = "txtMauso2";
            this.txtMauso2.Size = new System.Drawing.Size(120, 30);
            this.txtMauso2.TabIndex = 3;
            this.txtMauso2.TextChanged += new System.EventHandler(this.txtMauso2_TextChanged);
            // 
            // txtTuso2
            // 
            this.txtTuso2.Location = new System.Drawing.Point(149, 50);
            this.txtTuso2.Name = "txtTuso2";
            this.txtTuso2.Size = new System.Drawing.Size(120, 30);
            this.txtTuso2.TabIndex = 2;
            this.txtTuso2.TextChanged += new System.EventHandler(this.txtTuso2_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(43, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "Mẫu số:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(46, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 25);
            this.label4.TabIndex = 0;
            this.label4.Text = "Tử số:";
            // 
            // grpPhepTinh
            // 
            this.grpPhepTinh.Controls.Add(this.btnThuong);
            this.grpPhepTinh.Controls.Add(this.btnTich);
            this.grpPhepTinh.Controls.Add(this.btnHieu);
            this.grpPhepTinh.Controls.Add(this.btnSum);
            this.grpPhepTinh.Location = new System.Drawing.Point(105, 344);
            this.grpPhepTinh.Name = "grpPhepTinh";
            this.grpPhepTinh.Size = new System.Drawing.Size(293, 184);
            this.grpPhepTinh.TabIndex = 2;
            this.grpPhepTinh.TabStop = false;
            this.grpPhepTinh.Text = "Phép Tính";
            this.grpPhepTinh.Enter += new System.EventHandler(this.grpPhepTinh_Enter);
            // 
            // btnThuong
            // 
            this.btnThuong.Location = new System.Drawing.Point(167, 104);
            this.btnThuong.Name = "btnThuong";
            this.btnThuong.Size = new System.Drawing.Size(102, 41);
            this.btnThuong.TabIndex = 3;
            this.btnThuong.Text = "Chia";
            this.btnThuong.UseVisualStyleBackColor = true;
            this.btnThuong.Click += new System.EventHandler(this.btnThuong_Click);
            // 
            // btnTich
            // 
            this.btnTich.Location = new System.Drawing.Point(27, 104);
            this.btnTich.Name = "btnTich";
            this.btnTich.Size = new System.Drawing.Size(115, 41);
            this.btnTich.TabIndex = 2;
            this.btnTich.Text = "Nhân";
            this.btnTich.UseVisualStyleBackColor = true;
            this.btnTich.Click += new System.EventHandler(this.btnTich_Click);
            // 
            // btnHieu
            // 
            this.btnHieu.Location = new System.Drawing.Point(167, 40);
            this.btnHieu.Name = "btnHieu";
            this.btnHieu.Size = new System.Drawing.Size(102, 40);
            this.btnHieu.TabIndex = 1;
            this.btnHieu.Text = "Trừ";
            this.btnHieu.UseVisualStyleBackColor = true;
            this.btnHieu.Click += new System.EventHandler(this.btnHieu_Click);
            // 
            // btnSum
            // 
            this.btnSum.Location = new System.Drawing.Point(27, 40);
            this.btnSum.Name = "btnSum";
            this.btnSum.Size = new System.Drawing.Size(115, 40);
            this.btnSum.TabIndex = 0;
            this.btnSum.Text = "Cộng";
            this.btnSum.UseVisualStyleBackColor = true;
            this.btnSum.Click += new System.EventHandler(this.btnSum_Click);
            // 
            // grpKq
            // 
            this.grpKq.Controls.Add(this.txtKQMau);
            this.grpKq.Controls.Add(this.txtKQTu);
            this.grpKq.Controls.Add(this.label5);
            this.grpKq.Controls.Add(this.label6);
            this.grpKq.Location = new System.Drawing.Point(560, 344);
            this.grpKq.Name = "grpKq";
            this.grpKq.Size = new System.Drawing.Size(293, 184);
            this.grpKq.TabIndex = 3;
            this.grpKq.TabStop = false;
            this.grpKq.Text = "Kết Quả";
            this.grpKq.Enter += new System.EventHandler(this.grpKq_Enter);
            // 
            // txtKQMau
            // 
            this.txtKQMau.Location = new System.Drawing.Point(149, 107);
            this.txtKQMau.Name = "txtKQMau";
            this.txtKQMau.Size = new System.Drawing.Size(120, 30);
            this.txtKQMau.TabIndex = 3;
            // 
            // txtKQTu
            // 
            this.txtKQTu.Location = new System.Drawing.Point(149, 50);
            this.txtKQTu.Name = "txtKQTu";
            this.txtKQTu.Size = new System.Drawing.Size(120, 30);
            this.txtKQTu.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(43, 110);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 25);
            this.label5.TabIndex = 1;
            this.label5.Text = "Mẫu số:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(46, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 25);
            this.label6.TabIndex = 0;
            this.label6.Text = "Tử số:";
            // 
            // btnTiep
            // 
            this.btnTiep.Location = new System.Drawing.Point(983, 91);
            this.btnTiep.Name = "btnTiep";
            this.btnTiep.Size = new System.Drawing.Size(148, 127);
            this.btnTiep.TabIndex = 4;
            this.btnTiep.Text = "Tiếp Tục";
            this.btnTiep.UseVisualStyleBackColor = true;
            this.btnTiep.Click += new System.EventHandler(this.btnTiep_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Location = new System.Drawing.Point(983, 384);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(148, 127);
            this.btnThoat.TabIndex = 5;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label7.Location = new System.Drawing.Point(395, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(330, 39);
            this.label7.TabIndex = 6;
            this.label7.Text = "Phép Tính Phân Số";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1300, 703);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnTiep);
            this.Controls.Add(this.grpKq);
            this.Controls.Add(this.grpPhepTinh);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Phân Số";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.grpPhepTinh.ResumeLayout(false);
            this.grpKq.ResumeLayout(false);
            this.grpKq.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtMauSo1;
        private System.Windows.Forms.TextBox txtTuSo1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtMauso2;
        private System.Windows.Forms.TextBox txtTuso2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox grpPhepTinh;
        private System.Windows.Forms.Button btnHieu;
        private System.Windows.Forms.Button btnSum;
        private System.Windows.Forms.Button btnThuong;
        private System.Windows.Forms.Button btnTich;
        private System.Windows.Forms.GroupBox grpKq;
        private System.Windows.Forms.TextBox txtKQMau;
        private System.Windows.Forms.TextBox txtKQTu;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnTiep;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Label label7;
    }
}

